import React from 'react'
import Membro from './Membro'

export default props => 
    <div>
        <Membro nome="Rafael" sobrenome="Silva" />
        <Membro nome="Daniela" sobrenome="Silva" />
        <Membro nome="Pedro" sobrenome="Silva" />
        <Membro nome="Ana" sobrenome="Silva" />
    </div>